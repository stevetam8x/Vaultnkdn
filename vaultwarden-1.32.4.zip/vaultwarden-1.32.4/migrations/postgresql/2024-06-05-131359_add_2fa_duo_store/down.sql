DROP TABLE twofactor_duo_ctx;

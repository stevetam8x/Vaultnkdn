DROP TABLE groups;
DROP TABLE groups_users;
DROP TABLE collections_groups;
ALTER TABLE attachments MODIFY file_size BIGINT NOT NULL;

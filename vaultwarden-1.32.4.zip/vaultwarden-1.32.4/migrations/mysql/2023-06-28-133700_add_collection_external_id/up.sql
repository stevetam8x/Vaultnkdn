ALTER TABLE collections ADD COLUMN external_id TEXT;

DROP TABLE sends;

ALTER TABLE users_organizations
ADD COLUMN reset_password_key TEXT;

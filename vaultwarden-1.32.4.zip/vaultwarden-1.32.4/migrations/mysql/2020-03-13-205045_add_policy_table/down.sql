DROP TABLE org_policies;

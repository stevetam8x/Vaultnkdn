DROP TABLE event;

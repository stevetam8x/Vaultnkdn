ALTER TABLE users_organizations
ADD COLUMN external_id TEXT;

ALTER TABLE `twofactor_incomplete` DROP COLUMN `device_type`;

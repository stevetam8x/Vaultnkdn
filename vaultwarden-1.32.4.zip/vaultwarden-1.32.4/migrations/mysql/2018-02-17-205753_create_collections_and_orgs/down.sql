DROP TABLE collections;

DROP TABLE organizations;


DROP TABLE users_collections;

DROP TABLE users_organizations;
